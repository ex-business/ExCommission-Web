# Node 调用方 SDK

使用 `routedFetch` 替换受信跨服务请求；配置与Go SDK共用 `EX_ROUTER_DISCOVERY_CONFIG_FILE`。缓存最长3秒、故障冷却5秒、按优先级及轮询/权重选路，业务写请求不自动重放。

配置和边界见 [服务发现与直连路由](../docs/服务发现与直连路由.md)。本地包使用file依赖，正式发布前需发布固定版本。
