import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
test('JS发现保留Host与业务凭据，缓存轮询，写失败不重放并冷却',async()=>{
 const folder=await mkdtemp(join(tmpdir(),'router-sdk-'));let calls=0,queries=0,host,authorization;
 const listen=server=>new Promise(resolve=>server.listen(0,'127.0.0.1',()=>resolve('http://127.0.0.1:'+server.address().port)));
 const target=http.createServer((req,res)=>{calls++;host=req.headers.host;authorization=req.headers.authorization;res.writeHead(503);res.end('{}')});const targetURL=await listen(target);
 const registry=http.createServer((req,res)=>{queries++;assert.equal(req.headers.authorization,'Bearer machine-token-123');res.setHeader('content-type','application/json');res.end(JSON.stringify({service:'wallet',server_time_ms:1000,cache_ms:1000,instances:[{address:targetURL,instance:'one',expires_ms:3000}]}))});const node=await listen(registry);
 const file=join(folder,'config.json');await writeFile(file,JSON.stringify({nodes:[node],token:'machine-token-123',bindings:{'http://127.0.0.1:1':'wallet'}}),{mode:0o600});process.env.EX_ROUTER_DISCOVERY_CONFIG_FILE=file;
 try{const {routedFetch}=await import('./index.mjs?test');const response=await routedFetch('http://127.0.0.1:1/pay',{method:'POST',headers:{Authorization:'Bearer business',Host:'wallet.internal'}});assert.equal(response.status,503);await response.text();assert.equal(calls,1);assert.equal(host,'wallet.internal');assert.equal(authorization,'Bearer business');await assert.rejects(routedFetch('http://127.0.0.1:1/pay',{method:'POST'}),/健康/);assert.equal(calls,1);assert.equal(queries,1)}finally{delete process.env.EX_ROUTER_DISCOVERY_CONFIG_FILE;registry.closeAllConnections();target.closeAllConnections();await new Promise(r=>registry.close(r));await new Promise(r=>target.close(r));await rm(folder,{recursive:true,force:true})}
});
