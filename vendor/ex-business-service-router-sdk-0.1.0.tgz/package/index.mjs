import http from 'node:http';
import https from 'node:https';
import {Readable} from 'node:stream';
import {readFileSync,statSync} from 'node:fs';
const cache=new Map(),counters=new Map(),failed=new Map(),pending=new Map();
let config,loaded=false;
function load(){
 if(loaded)return config;
 const path=process.env.EX_ROUTER_DISCOVERY_CONFIG_FILE;
 if(!path){loaded=true;return null}
 const stat=statSync(path);
 if(!stat.isFile()||(stat.mode&0o077)||stat.size>131072)throw Error('服务发现配置必须为私有常规文件');
 const value=JSON.parse(readFileSync(path,'utf8'));
 if(!Array.isArray(value.nodes)||!value.nodes.length||value.nodes.length>16||Object.keys(value.bindings||{}).length>128||typeof value.token!=='string'||value.token.length<16||(!value.bindings||Object.keys(value.bindings).length===0))throw Error('服务发现配置无效');
 value.nodes.forEach(address);
 for(const [origin,service]of Object.entries(value.bindings)){const u=address(origin);if(u.origin!==origin||typeof service!=='string'||! /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/.test(service))throw Error('服务发现绑定无效')}
 config=value;loaded=true;return config;
}
function address(raw){const u=new URL(raw);if(u.username||u.password||u.search||u.hash||u.pathname!=='/'||(u.protocol!=='https:'&&!(u.protocol==='http:'&&u.hostname==='127.0.0.1')))throw Error('服务发现地址无效');return u}
async function refresh(service,cfg){
 for(const node of cfg.nodes){
  const started=Date.now();let response;
  try{response=await fetch(new URL('/v1/discovery?'+new URLSearchParams({service}),node),{headers:{Authorization:'Bearer '+cfg.token},redirect:'error',signal:AbortSignal.timeout(2000)})}catch{continue}
  if(response.status>=500){await response.body?.cancel();continue}
  if(response.status!==200){await response.body?.cancel();throw Error('目标服务发现被拒绝')}
  const raw=await response.text();if(raw.length>1048576)throw Error('发现响应过大');const body=JSON.parse(raw);
  if(body.service!==service||!Array.isArray(body.instances)||!Number.isFinite(body.server_time_ms))throw Error('发现响应无效');
  let ttl=Math.min(3000,body.cache_ms>0?body.cache_ms:3000);
  const targets=body.instances.filter(t=>t.expires_ms>body.server_time_ms).map(t=>{address(t.address);ttl=Math.min(ttl,t.expires_ms-body.server_time_ms);return t});
  const entry={targets,until:started+ttl};cache.set(service,entry);return entry;
 }
 throw Error('发现集群暂不可用');
}
async function resolve(service,cfg){
 let entry=cache.get(service);
 if(!entry||entry.until<=Date.now()){
  if(!pending.has(service))pending.set(service,refresh(service,cfg).finally(()=>pending.delete(service)));
  entry=await pending.get(service);
 }
 if(entry.until<=Date.now())throw Error('发现结果已过期');
 let targets=entry.targets.filter(t=>(failed.get(t.address)||0)<=Date.now());
 const priority=Math.min(...targets.map(t=>t.priority||0));targets=targets.filter(t=>(t.priority||0)===priority);
 if(!targets.length)throw Error('没有健康的目标实例');
 const weight=t=>Math.max(1,Math.min(1000,t.weight||1));const total=targets.reduce((n,t)=>n+weight(t),0);
 const count=counters.get(service)||0;counters.set(service,(count+1)%total);let position=count%total;
 for(const t of targets){if(position<weight(t))return t;position-=weight(t)}
 throw Error('路由策略无有效实例');
}
// 路由只改TCP目标，业务Host、Origin及签名头保持；结果未知的写请求绝不在SDK内重放。
export async function routedFetch(input,options={}){
 const cfg=load();const original=new URL(input);const service=cfg?.bindings[original.origin];
 if(!service)return fetch(input,options);
 const target=await resolve(service,cfg);const url=new URL(original);const endpoint=address(target.address);url.protocol=endpoint.protocol;url.host=endpoint.host;
 const headers=new Headers(options.headers);if(!headers.has('Host'))headers.set('Host',original.host);
 try{const response=await directRequest(url,{...options,headers});if(response.status>=500)failed.set(target.address,Date.now()+5000);return response}catch(error){failed.set(target.address,Date.now()+5000);throw error}
}

// Node fetch会重写Host；直连使用标准HTTP客户端保留原Host，同时TLS仍校验目标地址证书。
// 仅接受当前BFF使用的已缓冲正文，禁止在不明确可重放性时隐式消费流。
function directRequest(url,options){
 if(options.body!=null&&typeof options.body!=='string'&&!ArrayBuffer.isView(options.body))throw Error('直连正文类型不支持');
 return new Promise((resolve,reject)=>{
  const request=(url.protocol==='https:'?https:http).request(url,{method:options.method||'GET',headers:Object.fromEntries(options.headers),signal:options.signal},response=>{
   if([301,302,303,307,308].includes(response.statusCode)){response.resume();reject(Error('目标服务重定向被拒绝'));return}
   const headers=new Headers();for(let i=0;i<response.rawHeaders.length;i+=2)headers.append(response.rawHeaders[i],response.rawHeaders[i+1]);
   const noBody=options.method==='HEAD'||[204,205,304].includes(response.statusCode);
   if(noBody)response.resume();
   try{resolve(new Response(noBody?null:Readable.toWeb(response),{status:response.statusCode,statusText:response.statusMessage,headers}))}catch(error){response.destroy();reject(error)}
  });
  request.once('error',reject);request.end(options.body??undefined);
 });
}
